var BACKGROUND02 = [ "BACKGROUND02" , {
  BginnerRadius: 155,
  BgouterRadius: 116,
  BgFillColor: "#F2F2F2",
  BgborderColor : "#000",
  BgborderSize : 0.3,
  axisShow: "true",
  axisWidth: 0.1,
  axisColor: "#000",
  axisNum: 8
}];
