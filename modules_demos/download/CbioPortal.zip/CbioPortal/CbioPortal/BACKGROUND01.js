var BACKGROUND01 = [ "BACKGROUND01" , {
  BginnerRadius: 205,
  BgouterRadius: 173,
  BgFillColor: "#F2F2F2",
  BgborderColor : "#000",
  BgborderSize : 0.3,
  axisShow: "true",
  axisWidth: 0.1,
  axisColor: "#000",
  axisNum: 8
}];
