var ARC01 = [ "ARC01" , {
  innerRadius: 145,
  outerRadius: 155,
} , [
  {chr: "EGFR", start: "57", end: "167", color: "#CD8500", des: "Recep_L domain"},
  {chr: "EGFR", start: "185", end: "338", color: "blue", des: "Furin-like domain"},
  {chr: "EGFR", start: "361", end: "480", color: "#CD8500", des: "Recep_L domain"},
  {chr: "EGFR", start: "505", end: "636", color: "yellow", des: "GF_recep_IV domain"},
  {chr: "EGFR", start: "713", end: "965", color: "red", des: "Pkinase Tyr domain"},
]];
