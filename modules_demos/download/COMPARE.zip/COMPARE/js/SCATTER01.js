var SCATTER01 = [ "SCATTER01" , {
  SCATTERRadius: 220,
  innerCircleSize: 1,
  outerCircleSize: 7,
  innerCircleColor: "red",
  outerCircleColor: "#CC3399",
  innerPointType: "circle", //circle,rect
  outerPointType: "circle", //circle,rect
  innerrectWidth: 2,
  innerrectHeight: 2,
  outerrectWidth: 10,
  outerrectHeight: 10,
  outerCircleOpacity: 1,
  random_data: 0
} , [
  {chr: "1", start: "1102484", end: "1102578", name: "hsa-mir-200b", des: "breast cancer"},
  {chr: "11", start: "122017230", end: "122017301", name: "hsa-let-7a-2", des: "ovarian cancer"},
  {chr: "22", start: "46508629", end: "46508702", name: "hsa-let-7a-3", des: "leukemia cancer"},
  {chr: "14", start: "101349316", end: "101349412", name: "hsa-mir-127", des: "breast cancer"},
]];
